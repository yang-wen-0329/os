#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/utsname.h>
#include <linux/mm.h>
#include <linux/sysinfo.h>
#include <linux/sched/signal.h>
#include <linux/timekeeping.h>
#include <linux/cpumask.h>

#define DEVICE_NAME "kfetch"
#define BUF_SIZE    1024

#define KCOLOR "\033[1;33m"   // 粗體黃色
#define KRESET "\033[0m"      // reset 顏色


#define KFETCH_NUM_INFO   6
#define KFETCH_RELEASE    (1 << 0)
#define KFETCH_NUM_CPUS   (1 << 1)
#define KFETCH_CPU_MODEL  (1 << 2)
#define KFETCH_MEM        (1 << 3)
#define KFETCH_UPTIME     (1 << 4)
#define KFETCH_NUM_PROCS  (1 << 5)
#define KFETCH_FULL_INFO  ((1 << KFETCH_NUM_INFO) - 1)

static dev_t kfetch_dev;
static struct cdev kfetch_cdev;
static struct class *kfetch_class;

static int info_mask = KFETCH_FULL_INFO;
static DEFINE_MUTEX(kfetch_mutex);
static char kfetch_buf[BUF_SIZE];

static int kfetch_open(struct inode *inode, struct file *filp);
static int kfetch_release(struct inode *inode, struct file *filp);
static ssize_t kfetch_read(struct file *filp, char __user *buffer,
                           size_t length, loff_t *offset);
static ssize_t kfetch_write(struct file *filp, const char __user *buffer,
                            size_t length, loff_t *offset);

static const struct file_operations kfetch_ops = {
    .owner   = THIS_MODULE,
    .open    = kfetch_open,
    .release = kfetch_release,
    .read    = kfetch_read,
    .write   = kfetch_write,
};

/* ---- Helper functions ---- */

static void kfetch_get_hostname(char *buf, size_t size)
{
    strscpy(buf, init_uts_ns.name.nodename, size);
}

static void kfetch_get_release(char *buf, size_t size)
{
    strscpy(buf, init_uts_ns.name.release, size);
}

/* 簡版：先用 machine 名稱當 CPU model，之後你想加強再改 */
static void kfetch_get_cpu_model(char *buf, size_t size)
{
    strscpy(buf, init_uts_ns.name.machine, size);
}

static void kfetch_get_cpus(char *buf, size_t size)
{
    int online = num_online_cpus();
    int total  = num_possible_cpus();

    scnprintf(buf, size, "%d / %d", online, total);
}

static void kfetch_get_mem(char *buf, size_t size)
{
    struct sysinfo si;
    unsigned long total_mb, free_mb;

    si_meminfo(&si);
    total_mb = (si.totalram * si.mem_unit) >> 20;
    free_mb  = (si.freeram  * si.mem_unit) >> 20;

    scnprintf(buf, size, "%lu MB / %lu MB", free_mb, total_mb);
}

static int kfetch_count_procs(void)
{
    struct task_struct *task;
    int count = 0;

    rcu_read_lock();
    for_each_process(task)
        count++;
    rcu_read_unlock();

    return count;
}

static void kfetch_get_procs(char *buf, size_t size)
{
    int n = kfetch_count_procs();
    scnprintf(buf, size, "%d", n);
}

static void kfetch_get_uptime(char *buf, size_t size)
{
    u64 sec = ktime_get_boottime_seconds();
    u64 min = sec / 60;

    scnprintf(buf, size, "%llu mins", min);
}

/* 左邊的 ASCII 企鵝（跟講義版本接近） */
static const char *logo_lines[] = {
    "        .-.        ",
    "       (.. |       ",
    "       "KCOLOR"<>"KRESET"  |       ",
    "      / --- \\      ",
    "     ( |   | )     ",
    "   "KCOLOR"|\\"KRESET"\\_)__(_/"KCOLOR"/|"KRESET"   ",
    "  "KCOLOR"<__)"KRESET"------"KCOLOR"(__>"KRESET"   "
};
static const int logo_lines_count = sizeof(logo_lines) / sizeof(logo_lines[0]);

/* 算「畫面上實際看到」的長度（忽略 ANSI 顏色碼） */
static int kfetch_visible_len(const char *s)
{
    int vis = 0;

    while (*s) {
        if (*s == '\033') {
            /* 跳過 ESC 開頭的顏色序列：\033[...m */
            s++;
            if (*s == '[') {
                s++;
                while (*s && *s != 'm')
                    s++;
                if (*s == 'm')
                    s++;
            }
        } else {
            vis++;
            s++;
        }
    }
    return vis;
}

static size_t kfetch_build_output(char *buf, size_t size)
{
    char hostname[64];
    char release[64];
    char cpu_model[64];
    char cpu_str[32];
    char mem_str[64];
    char procs_str[32];
    char uptime_str[32];

    /* 右邊每一行要印的東西 */
    char info_lines[16][128];
    int info_cnt = 0;

    size_t len = 0;
    int i, j;

    /* 先收集各種資訊 */
    kfetch_get_hostname(hostname, sizeof(hostname));
    kfetch_get_release(release, sizeof(release));
    kfetch_get_cpu_model(cpu_model, sizeof(cpu_model));
    kfetch_get_cpus(cpu_str, sizeof(cpu_str));
    kfetch_get_mem(mem_str, sizeof(mem_str));
    kfetch_get_procs(procs_str, sizeof(procs_str));
    kfetch_get_uptime(uptime_str, sizeof(uptime_str));

    /* 右邊第 1 行：hostname */
    scnprintf(info_lines[info_cnt++], sizeof(info_lines[0]),
              "%s", hostname);

    /* 右邊第 2 行：分隔線，長度跟 hostname 一樣 */
    {
        int n = strlen(hostname);
        int maxn = sizeof(info_lines[0]) - 1;
        if (n > maxn)
            n = maxn;
        for (i = 0; i < n; i++)
            info_lines[info_cnt][i] = '-';
        info_lines[info_cnt][n] = '\0';
        info_cnt++;
    }

    /* 後面依 mask 決定要不要顯示，每行裡面「標題」用黃色 */
    if (info_mask & KFETCH_RELEASE)
        scnprintf(info_lines[info_cnt++], sizeof(info_lines[0]),
                  KCOLOR "Kernel:" KRESET " %s", release);

    if (info_mask & KFETCH_CPU_MODEL)
        scnprintf(info_lines[info_cnt++], sizeof(info_lines[0]),
                  KCOLOR "CPU:" KRESET "    %s", cpu_model);

    if (info_mask & KFETCH_NUM_CPUS)
        scnprintf(info_lines[info_cnt++], sizeof(info_lines[0]),
                  KCOLOR "CPUs:" KRESET "   %s", cpu_str);

    if (info_mask & KFETCH_MEM)
        scnprintf(info_lines[info_cnt++], sizeof(info_lines[0]),
                  KCOLOR "Mem:" KRESET "    %s", mem_str);

    if (info_mask & KFETCH_NUM_PROCS)
        scnprintf(info_lines[info_cnt++], sizeof(info_lines[0]),
                  KCOLOR "Procs:" KRESET "  %s", procs_str);

    if (info_mask & KFETCH_UPTIME)
        scnprintf(info_lines[info_cnt++], sizeof(info_lines[0]),
                  KCOLOR "Uptime:" KRESET " %s", uptime_str);

    /* 算出 logo 的最大「可見」寬度，讓右邊對齊 */
    int logo_width = 0;
    for (i = 0; i < logo_lines_count; i++) {
        int w = kfetch_visible_len(logo_lines[i]);
        if (w > logo_width)
            logo_width = w;
    }

    /* 一行一行輸出：左邊 logo，右邊 info */
    {
        int max_lines = (logo_lines_count > info_cnt) ? logo_lines_count : info_cnt;

        for (i = 0; i < max_lines && len < size; i++) {
            const char *logo = (i < logo_lines_count) ? logo_lines[i] : "";
            const char *info = (i < info_cnt) ? info_lines[i] : "";
            int logo_vis_len = kfetch_visible_len(logo);

            /* 印左邊 logo */
            len += scnprintf(buf + len, size - len, "%s", logo);

            /* 補空白，把右邊對齊到同一欄 */
            {
                int pad = logo_width - logo_vis_len + 2;  // +2 當間距
                for (j = 0; j < pad && len < size; j++)
                    buf[len++] = ' ';
            }

            /* 印右邊 info */
            len += scnprintf(buf + len, size - len, "%s\n", info);
        }
    }

    return len;
}


/* ---- file_operations ---- */

static int kfetch_open(struct inode *inode, struct file *filp)
{
    pr_debug("kfetch: open\n");
    return 0;
}

static int kfetch_release(struct inode *inode, struct file *filp)
{
    pr_debug("kfetch: release\n");
    return 0;
}

static ssize_t kfetch_write(struct file *filp, const char __user *buffer,
                            size_t length, loff_t *offset)
{
    int mask_info;

    if (length < sizeof(int))
        return -EINVAL;

    if (mutex_lock_interruptible(&kfetch_mutex))
        return -ERESTARTSYS;

    if (copy_from_user(&mask_info, buffer, sizeof(int))) {
        mutex_unlock(&kfetch_mutex);
        pr_alert("kfetch: Failed to copy data from user\n");
        return -EFAULT;
    }

    mask_info &= KFETCH_FULL_INFO;
    if (mask_info == 0)
        mask_info = KFETCH_FULL_INFO;

    info_mask = mask_info;

    mutex_unlock(&kfetch_mutex);

    return sizeof(int);
}

static ssize_t kfetch_read(struct file *filp, char __user *buffer,
                           size_t length, loff_t *offset)
{
    size_t len;

    if (*offset > 0)
        return 0;

    if (mutex_lock_interruptible(&kfetch_mutex))
        return -ERESTARTSYS;

    memset(kfetch_buf, 0, sizeof(kfetch_buf));
    len = kfetch_build_output(kfetch_buf, sizeof(kfetch_buf));

    if (len > length)
        len = length;

    if (copy_to_user(buffer, kfetch_buf, len)) {
        mutex_unlock(&kfetch_mutex);
        pr_alert("kfetch: Failed to copy data to user\n");
        return -EFAULT;
    }

    mutex_unlock(&kfetch_mutex);

    *offset += len;
    return len;
}

/* ---- module init / exit ---- */

static int __init kfetch_init(void)
{
    int ret;

    ret = alloc_chrdev_region(&kfetch_dev, 0, 1, DEVICE_NAME);
    if (ret < 0) {
        pr_err("kfetch: alloc_chrdev_region failed\n");
        return ret;
    }

    cdev_init(&kfetch_cdev, &kfetch_ops);
    kfetch_cdev.owner = THIS_MODULE;

    ret = cdev_add(&kfetch_cdev, kfetch_dev, 1);
    if (ret < 0) {
        pr_err("kfetch: cdev_add failed\n");
        unregister_chrdev_region(kfetch_dev, 1);
        return ret;
    }

    kfetch_class = class_create(DEVICE_NAME);
    if (IS_ERR(kfetch_class)) {
        pr_err("kfetch: class_create failed\n");
        ret = PTR_ERR(kfetch_class);
        cdev_del(&kfetch_cdev);
        unregister_chrdev_region(kfetch_dev, 1);
        return ret;
    }

    if (!device_create(kfetch_class, NULL, kfetch_dev, NULL, DEVICE_NAME)) {
        pr_err("kfetch: device_create failed\n");
        class_destroy(kfetch_class);
        cdev_del(&kfetch_cdev);
        unregister_chrdev_region(kfetch_dev, 1);
        return -ENOMEM;
    }

    pr_info("kfetch: module loaded\n");
    return 0;
}

static void __exit kfetch_exit(void)
{
    device_destroy(kfetch_class, kfetch_dev);
    class_destroy(kfetch_class);
    cdev_del(&kfetch_cdev);
    unregister_chrdev_region(kfetch_dev, 1);
    pr_info("kfetch: module unloaded\n");
}

module_init(kfetch_init);
module_exit(kfetch_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("<your_name>");
MODULE_DESCRIPTION("System information fetching kernel module for OS HW3");
