#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <time.h>
#include <sched.h>   // for sched_param, SCHED_FIFO, CPU_SET, etc.

/* Simple enum for scheduling policy */
typedef enum {
    POLICY_NORMAL,
    POLICY_FIFO
} my_policy_t;

/* Global variables for parsed options */
int num_threads = 0;       // from -n
double busy_time = 0.0;    // from -t
char *s_arg = NULL;        // raw string from -s
char *p_arg = NULL;        // raw string from -p

my_policy_t *policies = NULL;  // array of length num_threads
int *priorities = NULL;        // array of length num_threads

/* Barrier to start all worker threads at the same time */
pthread_barrier_t start_barrier;

/* Per-thread argument */
typedef struct {
    int id;   // thread index: 0, 1, 2, ...
} thread_arg_t;

/* Busy-wait for given seconds using thread CPU time */
void busy_wait(double seconds)
{
    struct timespec start, now;
    long target_ns = (long)(seconds * 1000000000L);

    /* CLOCK_THREAD_CPUTIME_ID counts CPU time consumed by this thread */
    clock_gettime(CLOCK_THREAD_CPUTIME_ID, &start);

    for (;;) {
        clock_gettime(CLOCK_THREAD_CPUTIME_ID, &now);
        long elapsed_ns =
            (now.tv_sec - start.tv_sec) * 1000000000L +
            (now.tv_nsec - start.tv_nsec);

        if (elapsed_ns >= target_ns)
            break;
    }
}

/* Parse the -s option: "NORMAL,FIFO,..." into an array */
void parse_policy_list(const char *str)
{
    policies = malloc(sizeof(my_policy_t) * num_threads);
    if (!policies) {
        perror("malloc policies");
        exit(1);
    }

    char *tmp = strdup(str);        // make a writable copy
    char *token = strtok(tmp, ","); // split by comma
    int i = 0;

    while (token && i < num_threads) {
        if (strcmp(token, "NORMAL") == 0) {
            policies[i] = POLICY_NORMAL;
        } else if (strcmp(token, "FIFO") == 0) {
            policies[i] = POLICY_FIFO;
        } else {
            /* default to NORMAL if unknown */
            policies[i] = POLICY_NORMAL;
        }
        i++;
        token = strtok(NULL, ",");
    }

    free(tmp);
}

/* Parse the -p option: "-1,10,30,..." into an int array */
void parse_priority_list(const char *str)
{
    priorities = malloc(sizeof(int) * num_threads);
    if (!priorities) {
        perror("malloc priorities");
        exit(1);
    }

    char *tmp = strdup(str);
    char *token = strtok(tmp, ",");
    int i = 0;

    while (token && i < num_threads) {
        priorities[i] = atoi(token);
        i++;
        token = strtok(NULL, ",");
    }

    free(tmp);
}

/* Worker thread function */
void *worker_thread(void *arg)
{
    thread_arg_t *info = (thread_arg_t *)arg;
    int id = info->id;

    /* 1. Wait until all threads are ready */
    pthread_barrier_wait(&start_barrier);

    /* 2. Do the task 3 times */
    for (int i = 0; i < 3; i++) {
        printf("Thread %d is running\n", id);
        fflush(stdout);      // flush output immediately
        busy_wait(busy_time);
    }

    return NULL;
}

/* Set CPU affinity of a thread to CPU 0 */
void set_thread_affinity(pthread_t th)
{
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(0, &cpuset);  // bind to CPU 0

    int ret = pthread_setaffinity_np(th, sizeof(cpu_set_t), &cpuset);
    if (ret != 0) {
        // For this assignment we do not need strict error handling
        // fprintf(stderr, "pthread_setaffinity_np failed: %d\n", ret);
    }
}

/* Set scheduling policy and priority for a thread */
void set_thread_sched(pthread_t th, my_policy_t policy, int prio)
{
    struct sched_param sp;
    int sched_policy;

    if (policy == POLICY_FIFO && prio > 0) {
        sched_policy = SCHED_FIFO;
        sp.sched_priority = prio;
    } else {
        /* Use normal fair scheduler (CFS) */
        sched_policy = SCHED_OTHER;
        sp.sched_priority = 0;
    }

    int ret = pthread_setschedparam(th, sched_policy, &sp);
    if (ret != 0) {
        // If it fails (e.g., not enough privilege), we just ignore it
        // fprintf(stderr, "pthread_setschedparam failed: %d\n", ret);
    }
}

int main(int argc, char *argv[])
{
    int opt;

    /* 1. Parse command-line options: -n -t -s -p */
    while ((opt = getopt(argc, argv, "n:t:s:p:")) != -1) {
        switch (opt) {
        case 'n':
            num_threads = atoi(optarg);   // convert string to int
            break;
        case 't':
            busy_time = atof(optarg);     // convert string to double
            break;
        case 's':
            s_arg = optarg;               // remember raw string
            break;
        case 'p':
            p_arg = optarg;               // remember raw string
            break;
        default:
            /* no strict error handling needed in this assignment */
            break;
        }
    }

    /* 2. Basic check: we need all options and a positive thread count */
    if (!s_arg || !p_arg || num_threads <= 0) {
        fprintf(stderr,
                "Usage: %s -n <num> -t <sec> -s <policies> -p <priorities>\n",
                argv[0]);
        return 1;
    }

    /* 3. Parse -s and -p into arrays */
    parse_policy_list(s_arg);
    parse_priority_list(p_arg);

    /* 4. Create worker threads */
    pthread_t *threads = malloc(sizeof(pthread_t) * num_threads);
    thread_arg_t *args = malloc(sizeof(thread_arg_t) * num_threads);

    if (!threads || !args) {
        perror("malloc threads/args");
        return 1;
    }

    /* Initialize barrier: all worker threads must wait together */
    if (pthread_barrier_init(&start_barrier, NULL, num_threads) != 0) {
        perror("pthread_barrier_init");
        return 1;
    }

    /* Create threads */
    for (int i = 0; i < num_threads; i++) {
        args[i].id = i;
        if (pthread_create(&threads[i], NULL, worker_thread, &args[i]) != 0) {
            perror("pthread_create");
            return 1;
        }
    }

    /* 5. Set CPU affinity and scheduling for each thread */
    for (int i = 0; i < num_threads; i++) {
        set_thread_affinity(threads[i]);
        set_thread_sched(threads[i], policies[i], priorities[i]);
    }

    /* 6. Wait for all threads to finish */
    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    /* 7. Clean up */
    pthread_barrier_destroy(&start_barrier);
    free(threads);
    free(args);
    free(policies);
    free(priorities);

    return 0;
}
